from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pejo.core.logging import RunLogger
from pejo.core.hashing import apply_hashing_strategy
from pejo.core.merge_builder import build_delta_merge_sql, build_scd2_sql
from pejo.schemas import load_metadata_from_yaml


@dataclass(frozen=True)
class DomainRunResult:
    domain: str
    tables: list[str]


@dataclass(frozen=True)
class TableListRunResult:
    tables: list[str]


@dataclass(frozen=True)
class DryRunResult:
    table: str
    sql_statements: list[str]


@dataclass(frozen=True)
class ValidationResult:
    tables: list[str]


class Engine:
    """Execution engine for table and domain runs."""
    SCD2_REQUIRED_COLUMNS = {
        "valid_from": "TIMESTAMP",
        "valid_to": "TIMESTAMP",
        "is_current": "BOOLEAN",
        "row_hash": "STRING",
    }

    def __init__(
        self,
        spark,
        metadata: dict[str, dict[str, Any]],
        adapter,
        bronze_lakehouse: str | None = None,
        lakehouse_id: str | None = None,
    ):
        self.spark = spark
        self.metadata = metadata
        self.adapter = adapter
        self.bronze_lakehouse = bronze_lakehouse or lakehouse_id

    @classmethod
    def from_yaml_dir(
        cls,
        spark,
        adapter,
        schema_dir: str | Path,
        bronze_lakehouse: str | None = None,
        lakehouse_id: str | None = None,
    ) -> "Engine":
        metadata = load_metadata_from_yaml(schema_dir)
        return cls(
            spark=spark,
            metadata=metadata,
            adapter=adapter,
            bronze_lakehouse=bronze_lakehouse,
            lakehouse_id=lakehouse_id,
        )

    def run(self, table_name: str) -> None:
        logger = RunLogger(self.spark)
        logger.start(table_name)

        try:
            df, sql_statements = self._plan_for_table(table_name)
            config = self.metadata[table_name]
            self._ensure_target_table(config["silver"])

            if str(config.get("scdtype", "SCD1")).upper() == "SCD2":
                self._ensure_scd2_target_columns(config["silver"])

            for statement in sql_statements:
                self.spark.sql(statement)

            logger.end(status="SUCCESS", rows_source=df.count())
        except Exception as exc:
            logger.end(status="FAILED", error_message=str(exc))
            raise

    def run_domain(self, domain: str) -> DomainRunResult:
        tables = self._resolve_tables(domain=domain)

        for table_name in tables:
            self.run(table_name)

        return DomainRunResult(domain=domain, tables=tables)

    def run_table_list(self, table_names: list[str]) -> TableListRunResult:
        tables = self._resolve_tables(table_names=table_names)
        for table_name in tables:
            self.run(table_name)
        return TableListRunResult(tables=tables)

    def dry_run(self, table_name: str) -> DryRunResult:
        _df, sql_statements = self._plan_for_table(table_name)
        return DryRunResult(table=table_name, sql_statements=sql_statements)

    def validate_only(
        self,
        table_name: str | None = None,
        domain: str | None = None,
        table_names: list[str] | None = None,
    ) -> ValidationResult:
        tables = self._resolve_tables(table_name=table_name, domain=domain, table_names=table_names)
        for name in tables:
            self._plan_for_table(name)
        return ValidationResult(tables=tables)

    def _resolve_tables(
        self,
        table_name: str | None = None,
        domain: str | None = None,
        table_names: list[str] | None = None,
    ) -> list[str]:
        specified = [table_name is not None, domain is not None, table_names is not None]
        if sum(specified) != 1:
            raise ValueError("Specify exactly one of: table_name, domain, table_names")

        if table_name is not None:
            if table_name not in self.metadata:
                raise ValueError(f"Unknown table '{table_name}'")
            return [table_name]

        if table_names is not None:
            if not table_names:
                raise ValueError("table_names cannot be empty")
            unknown = [name for name in table_names if name not in self.metadata]
            if unknown:
                raise ValueError(f"Unknown table(s): {', '.join(unknown)}")
            return table_names

        tables = [
            name
            for name, config in self.metadata.items()
            if str(config.get("domain", "")).lower() == str(domain).lower()
        ]
        if not tables:
            raise ValueError(f"No tables found for domain '{domain}'")
        return tables

    def _plan_for_table(self, table_name: str) -> tuple[Any, list[str]]:
        config = self.metadata[table_name]

        bronze_table = self._resolve_bronze_table(config)
        df = self.spark.table(bronze_table)
        df = self.adapter.transform(df)
        df = self.adapter.apply_features(self.spark, df, config)
        df = apply_hashing_strategy(df, config)
        df.createOrReplaceTempView("source_view")

        columns = df.columns
        keys = config.get("primary_key") or []
        if not keys:
            raise ValueError(
                f"Missing required `primary_key` for table '{table_name}'. "
                "Define `primary_key` in schema."
            )
        column_aliases = {
            str(column_name): str(settings.get("alias"))
            for column_name, settings in (config.get("columns") or {}).items()
            if settings.get("alias")
        }

        load_type = str(config.get("load_type", "delta_merge")).lower()
        if load_type != "delta_merge":
            raise ValueError(f"Unsupported load_type '{load_type}'. Only 'delta_merge' is supported.")

        scd_type = str(config.get("scdtype", "SCD1")).upper()
        if scd_type == "SCD2":
            merge_sql = build_scd2_sql(
                target=config["silver"],
                source_view="source_view",
                keys=keys,
                columns=columns,
                column_aliases=column_aliases,
            )
            return df, [merge_sql]
        if scd_type == "SCD1":
            merge_sql = build_delta_merge_sql(
                target=config["silver"],
                source_view="source_view",
                keys=keys,
                columns=columns,
                soft_delete=config.get("soft_delete"),
                column_aliases=column_aliases,
            )
            return df, [merge_sql]

        raise ValueError(f"Unsupported scdtype '{scd_type}'. Use 'SCD1' or 'SCD2'.")

    def _resolve_bronze_table(self, config: dict[str, Any]) -> str:
        bronze_table = str(config["bronze"])
        if "." in bronze_table:
            return bronze_table

        lakehouse = self.bronze_lakehouse or config.get("bronze_lakehouse")
        if not lakehouse:
            return bronze_table

        return f"{lakehouse}.{bronze_table}"

    def _ensure_scd2_target_columns(self, target_table: str) -> None:
        target_df = self.spark.table(target_table)
        existing_columns: set[str] = set()

        schema = getattr(target_df, "schema", None)
        fields = getattr(schema, "fields", None) if schema is not None else None
        if fields:
            existing_columns = {str(field.name).lower() for field in fields}
        elif hasattr(target_df, "columns"):
            existing_columns = {str(column).lower() for column in target_df.columns}

        missing = [
            (column_name, data_type)
            for column_name, data_type in self.SCD2_REQUIRED_COLUMNS.items()
            if column_name.lower() not in existing_columns
        ]
        if not missing:
            return

        add_columns_sql = ", ".join([f"{column_name} {data_type}" for column_name, data_type in missing])
        self.spark.sql(f"ALTER TABLE {target_table} ADD COLUMNS ({add_columns_sql})")

    def _ensure_target_table(self, target_table: str) -> None:
        self.spark.sql(
            f"CREATE TABLE IF NOT EXISTS {target_table} USING DELTA "
            "AS SELECT * FROM source_view WHERE 1 = 0"
        )
